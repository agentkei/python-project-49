#!/usr/bin/env python3


from brain_games.games.brain_games import hello_user


def main():
    hello_user()


if __name__ == '__main__':
    main()

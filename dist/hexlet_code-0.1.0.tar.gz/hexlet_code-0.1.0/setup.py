# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games1', 'brain_games1.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games1.scripts.brain_calc:main',
                     'brain-even = brain_games1.scripts.brain_even:main',
                     'brain-games = brain_games1.scripts.brain_games:main',
                     'brain-gcd = brain_games1.scripts.brain_gcd:main',
                     'brain-prime = brain_games1.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games1.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/agentkei/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/agentkei/python-project-49/actions)\n<a href="https://codeclimate.com/github/agentkei/python-project-49/maintainability">\n<img src="https://api.codeclimate.com/v1/badges/9e13e803cdf37cbb85d5/maintainability" /></a>\n',
    'author': 'agentkei',
    'author_email': 'daniloff.konstantin2016@yandex.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8.1,<4.0.0',
}


setup(**setup_kwargs)

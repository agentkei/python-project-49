# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['mpmath>=1.2.1,<2.0.0',
 'numexpr>=2.8.4,<3.0.0',
 'numpy>=1.23.5,<2.0.0',
 'prompt>=0.4.1,<0.5.0',
 'sympy>=1.11.1,<2.0.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '# **Brain games**\n## This project demonstrates the process of the console-game "brain-games". It includes 6 modules:\n\n* Welcome with the player\'s name (brain-games)\n* Determining an even number (brain-even)\n* Calculate the mathematical ratio of two numbers (brain-calc)\n* Finding the largest divisor of two numbers (brain-gcd)\n* Search for an unknown number in arithmetic progression (brain-progression)\n* Definition of prime number (brain-prime)\n\n\n## Minimum requirements to run: \n* Windows operating system or lunix operating system\n* Python : 3.8\n\n## Launch instructions:\n1) **Downloading the project from github git clone:** https://github.com/agentkei/python-project-49\n2) **Install project:** pip install --user git+https://github.com/agentkei/python-project-49 \n3) **Games are launched using commands:**  *brain-games*; *brain-even*; *brain-calc*; *brain-gcd*; *brain-progression*; *brain-prime*.\n-------\n## **Hexlet tests and linter status:**\n[![Actions Status](https://github.com/agentkei/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/agentkei/python-project-49/actions)\n<a href="https://codeclimate.com/github/agentkei/python-project-49/maintainability">\n<img src="https://api.codeclimate.com/v1/badges/9e13e803cdf37cbb85d5/maintainability" /></a>\n\n\nbrain-games; brain-even (<script id="asciicast-cpsSTIzjW142GwlrDU76yDZWh" src="https://asciinema.org/a/cpsSTIzjW142GwlrDU76yDZWh.js" async></script>)\n\nbrain-calc (<script id="asciicast-8B978GI9dNuMG5BwHFzkhDvBK" src="https://asciinema.org/a/8B978GI9dNuMG5BwHFzkhDvBK.js" async></script>)\n\nbrain-gcd (<script id="asciicast-zOM5Jps2gGGFvJbXW1GtjWgTJ" src="https://asciinema.org/a/zOM5Jps2gGGFvJbXW1GtjWgTJ.js" async></script>)\n\nbrain-progression (<script id="asciicast-o6FxpFzCYwhlddBumJPChod5q" src="https://asciinema.org/a/o6FxpFzCYwhlddBumJPChod5q.js" async></script>)\n\nbrain-prime (<script id="asciicast-MUi535VsVV8Z87iTIQkSeVjhl" src="https://asciinema.org/a/MUi535VsVV8Z87iTIQkSeVjhl.js" async></script>)',
    'author': 'agentkei',
    'author_email': 'daniloff.konstantin2016@yandex.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8.1,<4.0.0',
}


setup(**setup_kwargs)

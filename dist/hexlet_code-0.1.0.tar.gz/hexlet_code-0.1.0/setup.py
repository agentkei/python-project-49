# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### 1) This project demonstrates the process of the game brain-game. It includes modules on  determining an even number, the greatest divisor of two numbers, an arithmetic progression, choosing a prime number, the ratio of two numbers, as well as a greeting ### with the player\'s name.  \n### Minimum requirements to run: Windows operating system or lunix operating system.  \n### Launch instructions: downloading the project from github, using commands for the player: brain-games; brain-even; brain-calc; brain-gcd; brain-progression; brain-prime. \n\n### Hexlet tests and linter status:\n[![Actions Status](https://github.com/agentkei/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/agentkei/python-project-49/actions)\n<a href="https://codeclimate.com/github/agentkei/python-project-49/maintainability">\n<img src="https://api.codeclimate.com/v1/badges/9e13e803cdf37cbb85d5/maintainability" /></a>\n\n\nbrain-games; brain-even (https://asciinema.org/a/cpsSTIzjW142GwlrDU76yDZWh)\n\nbrain-calc (https://asciinema.org/a/8B978GI9dNuMG5BwHFzkhDvBK)\n\nbrain-gcd (https://asciinema.org/a/zOM5Jps2gGGFvJbXW1GtjWgTJ)\n\nbrain-progression (https://asciinema.org/a/o6FxpFzCYwhlddBumJPChod5q)\n\nbrain-prime (https://asciinema.org/a/MUi535VsVV8Z87iTIQkSeVjhl)',
    'author': 'agentkei',
    'author_email': 'daniloff.konstantin2016@yandex.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8.1,<4.0.0',
}


setup(**setup_kwargs)

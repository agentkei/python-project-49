# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['numexpr>=2.8.4,<3.0.0', 'numpy>=1.23.5,<2.0.0', 'prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '# **Brain games**\n## This project demonstrates the process of the console-game "brain-games". It includes 6 modules:\n\n* Welcome with the player\'s name (brain-games)\n* Determining an even number (brain-even)\n* Calculate the mathematical ratio of two numbers (brain-calc)\n* Finding the largest divisor of two numbers (brain-gcd)\n* Search for an unknown number in arithmetic progression (brain-progression)\n* Definition of prime number (brain-prime)\n\n\n## Minimum requirements to run: \n* Windows operating system or lunix operating system\n* Python : 3.8\n\n## Launch instructions:\n* ```bahs git clone https://github.com/agentkei/python-project-49```\n\n2) **Install project:** pip install --user git+https://github.com/agentkei/python-project-49 \n3) **Games are launched using commands:**  *brain-games*; *brain-even*; *brain-calc*; *brain-gcd*; *brain-progression*; *brain-prime*.\n\n## **Hexlet tests and linter status:**\n[![Actions Status](https://github.com/agentkei/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/agentkei/python-project-49/actions)\n<a href="https://codeclimate.com/github/agentkei/python-project-49/maintainability">\n<img src="https://api.codeclimate.com/v1/badges/9e13e803cdf37cbb85d5/maintainability" /></a>\n\n\n### **brain-games and brain-even** [![asciicast](https://asciinema.org/a/cpsSTIzjW142GwlrDU76yDZWh.svg)](https://asciinema.org/a/cpsSTIzjW142GwlrDU76yDZWh)\n\n### **brain-calc** [![asciicast](https://asciinema.org/a/8B978GI9dNuMG5BwHFzkhDvBK.svg)](https://asciinema.org/a/8B978GI9dNuMG5BwHFzkhDvBK)\n\n### **brain-gcd** [![asciicast](https://asciinema.org/a/zOM5Jps2gGGFvJbXW1GtjWgTJ.svg)](https://asciinema.org/a/zOM5Jps2gGGFvJbXW1GtjWgTJ)\n\n### **brain-progression** [![asciicast](https://asciinema.org/a/o6FxpFzCYwhlddBumJPChod5q.svg)](https://asciinema.org/a/o6FxpFzCYwhlddBumJPChod5q)\n\n### **brain-prime** [![asciicast](https://asciinema.org/a/MUi535VsVV8Z87iTIQkSeVjhl.svg)](https://asciinema.org/a/MUi535VsVV8Z87iTIQkSeVjhl)',
    'author': 'agentkei',
    'author_email': 'daniloff.konstantin2016@yandex.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8.1,<4.0.0',
}


setup(**setup_kwargs)

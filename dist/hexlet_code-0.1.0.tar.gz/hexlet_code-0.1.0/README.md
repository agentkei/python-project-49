### 1) This project demonstrates the process of the game brain-game. It includes modules on  determining an even number, the greatest divisor of two numbers, an arithmetic progression, choosing a prime number, the ratio of two numbers, as well as a greeting ### with the player's name.  
### Minimum requirements to run: Windows operating system or lunix operating system.  
### Launch instructions: downloading the project from github, using commands for the player: brain-games; brain-even; brain-calc; brain-gcd; brain-progression; brain-prime. 

### Hexlet tests and linter status:
[![Actions Status](https://github.com/agentkei/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/agentkei/python-project-49/actions)
<a href="https://codeclimate.com/github/agentkei/python-project-49/maintainability">
<img src="https://api.codeclimate.com/v1/badges/9e13e803cdf37cbb85d5/maintainability" /></a>


brain-games; brain-even (https://asciinema.org/a/cpsSTIzjW142GwlrDU76yDZWh)

brain-calc (https://asciinema.org/a/8B978GI9dNuMG5BwHFzkhDvBK)

brain-gcd (https://asciinema.org/a/zOM5Jps2gGGFvJbXW1GtjWgTJ)

brain-progression (https://asciinema.org/a/o6FxpFzCYwhlddBumJPChod5q)

brain-prime (https://asciinema.org/a/MUi535VsVV8Z87iTIQkSeVjhl)
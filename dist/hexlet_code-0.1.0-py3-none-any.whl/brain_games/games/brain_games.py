from brain_games.cli import welcome_user


def hello_user():
    print('Welcome to the Brain Games!')
    return (welcome_user())
